package definition

import "nosuchpkg"

var _ nosuchpkg.T // @definition qualified-nopkg "nosuchpkg"
