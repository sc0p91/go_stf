// +build go1.8

package ir

import "go/types"

var structTypesIdentical = types.IdenticalIgnoreTags
