package Test

const Constant string = "const"
const OtherConst = "const"

const (
	A    = true
	B, C = "c", "d"
	_, D = 0, 0
)
