package main

import "fmt"

func main() {
	for range [3]int{} {
		fmt.Println("testing")
	}
}
