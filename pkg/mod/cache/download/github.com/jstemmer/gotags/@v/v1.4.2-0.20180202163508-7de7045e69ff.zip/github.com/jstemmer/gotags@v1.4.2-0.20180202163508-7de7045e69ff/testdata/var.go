package Test

var variable1 int
var variable2 string = "string"

var (
	A    = true
	B, C = "c", "d"
	_, D = 0, 0
)
