package Test

func Function1() string {
}

func function2(p1, p2 int, p3 *string) {
}

func function3() (result bool) {
}

func function4(p interface{}) interface{} {
}

func function5() (a, b string, c error) {
}

func function6(v ...interface{}) {
}

func function7(s ...string) {
}
