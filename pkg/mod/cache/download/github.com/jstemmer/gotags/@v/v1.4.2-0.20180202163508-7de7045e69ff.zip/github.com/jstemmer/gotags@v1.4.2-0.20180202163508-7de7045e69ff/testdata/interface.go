package Test

type Interface interface {
	InterfaceMethod(int) string
	OtherMethod()
	io.Reader
}
