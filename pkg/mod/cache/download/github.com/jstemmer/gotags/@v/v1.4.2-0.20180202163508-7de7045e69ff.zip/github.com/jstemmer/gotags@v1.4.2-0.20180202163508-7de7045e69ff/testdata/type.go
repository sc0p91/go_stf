package Test

type testType int
type testArrayType [4]int
type testSliceType []int
type testPointerType *string
type testFuncType1 func()
type testFuncType2 func(int) string
type testMapType map[string]bool
type testChanType chan bool
